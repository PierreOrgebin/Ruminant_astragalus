library(rgl) 
library(geomorph)
library(Morpho)
library(stats)
library(RColorBrewer)
library(vegan)
library(lattice)
library(RRphylo)
library(phytools)
library(ggplot2)
library(dplyr)


setwd("C:/Users/utilisateur/Desktop/Codes/R_codes/Extant+Extinct")
#############Creation of Data_mean_without_correction_of_Allometry##############

#Import coord from MorphoJ
coordData <- read.csv("CoordDataPhy.csv", sep=";")
coordData <- coordData[,-1] 
coordData <- arrayspecs(coordData, 426, 3)

#open sliders file
curves<-as.matrix(read.table(file = "Courbes.csv", header = F, sep=";", skip = 0, fill = TRUE)) #semilandmarks curves

#names
indivlist <- read.table(file = "IndivDataPhy.csv", header = F, sep=";", skip = 0, fill = TRUE) #names
dimnames(coordData)[3] <- indivlist	#name of the species are applied to the dataset

clades <- read.table(file = "CladeDataPhyAll.csv", header = F, sep=";", skip = 0, fill = TRUE) #groups 
clades <- unlist(clades, use.names=FALSE)

data<- list("land" = coordData, "curves"=curves, "species"=indivlist,"clades"=clades) #list with all previous files

str(data) #check that everything is in order


#check for NA data
any(is.na(data$land))

#gpa
R.gpa <- gpagen(coordData, curves=curves, ProcD = T)
gpa_2d <- two.d.array(R.gpa$coords) #GPA coords
row.names(gpa_2d) <- indivlist[,1]

#species
spe_class <- read.csv("SpeciesPhy.csv", sep=";", header=F)
rum2d_sp <- cbind.data.frame(spe_class[,2], gpa_2d)
split_sp <- split(rum2d_sp, rum2d_sp[,1])
row.names(rum2d_sp) <- indivlist[,1]

###mean
for (i in 1:108)
{
  split_sp[[i]] <- split_sp[[i]][,2:1279]
  df <- list(unique(spe_class[,2]))
  assign(paste("sp",i, sep=""), as.matrix(split_sp[[i]]))
  
  if (nrow(get(paste("sp",i, sep=""))) > 1) {
    assign(paste("df",i, sep=""), arrayspecs(get(paste0("sp", i)), 426, 3))
    assign(paste("df",i, sep=""), mshape(get(paste0("df", i))))
  }		
  
  else	{	
    assign(paste("df",i, sep=""), matrix(get(paste0("sp", i)), ncol=1278))
    assign(paste("df",i, sep=""), arrayspecs(get(paste0("df", i)), 426, 3))
  }		
  
}

#New dataset with one specimen per species
data_108 <- bindArr(df1,df2,df3,df4,df5,df6,df7,df8,df9,df10,df11,df12,df13,df14,
                    df15,df16,df17,df18,df19,df20,df21,df22,df23,df24,df25,df26,
                    df27,df28,df29,df30,df31,df32,df33,df34,df35,df36,df37,df38,
                    df39,df40,df41,df42,df43,df44,df45,df46,df47,df48,df49,df50,
                    df51,df52,df53,df54,df55,df56,df57,df58,df59,df60,df61,df62,
                    df63,df64,df65,df66,df67,df68,df69,df70,df71,df72,df73,df74,
                    df75,df76,df77,df78,df79,df80,df81,df82,df83,df84,df85,df86,
                    df87,df88,df89,df90,df91,df92,df93,df94,df95,df96,df97,df98,
                    df99,df100,df101,df102,df103,df104,df105,df106,df107,df108,along =3)

#data_mean creation
rm_names <- as.data.frame(ls(split_sp))
dimnames(data_108)[3] <- rm_names
clade_mean <- read.table(file = "CladeDataPhy.csv", header = F, sep=";", skip = 0, fill = TRUE) #groups 
clade_mean <- unlist(clade_mean, use.names=FALSE) #this step transform the dataset into "factors"

data_mean <- list("land" = data_108, "curves"=curves,"clades"=clade_mean, "species"=rm_names)
str(data_mean)

###data-mean procrustes et pca
R.gpa_mean <- gpagen(data_108, curves=curves, ProcD = T) #GPA
pca_mean <- gm.prcomp(R.gpa_mean$coord)#PCA

plotOutliers(R.gpa_mean$coords) #Check for problems

orpdata_exp <- pca_mean$x
gpa_2d_mean <- two.d.array(R.gpa_mean$coords) #GPA coords
row.names(gpa_2d_mean) <- rm_names[,1]

##Data-mean PCAVisualisation

#Plot

gp<-as.factor(unlist(clade_mean))
names(gp) <-row.names(clade_mean)
col.gp <- col.gp1 <- c("#D55E00", '#009E73','#F0E442','#CC79A7','black')
names(col.gp) <- levels(gp)
col.gp <- col.gp[match(gp, names(col.gp))]

shp.gp <- c(24,22,21,23,20)
names(shp.gp) <- levels(gp)
shp.gp <- shp.gp[match(gp, names(shp.gp))]

pdf('C:/Users/utilisateur/Desktop/Codes/R_codes/Extant+Extinct/PCA_DataPhy12_mean.pdf')
plot(pca_mean, pch = shp.gp, cex = 1.7, col = "black", bg=col.gp)
#text(pca_mean$x[,1], pca_mean$x[,2], cex = 0.7, pos = 4, col = col.gp)
dev.off()

#Shape
mymesh<-read.ply(file = "Palaeoryx_cordieri_NMB_Mp4631931.ply")

#myWarpeMean<-warpRefMesh(mymesh, mesh.coord=R.gpa$consensus,mshape(R.gpa$coords))
#writePLY("myWarpeMean.ply",  withColors = TRUE)
#PC1
PC1max<-warpRefMesh(myWarpeMean, mesh.coord=R.gpa$consensus,pca_mean$shapes$shapes.comp1$max )
#writePLY("PC1max.ply",  withColors = TRUE)
PC1min<-warpRefMesh(myWarpeMean, mesh.coord=R.gpa$consensus,pca_mean$shapes$shapes.comp1$min )
#writePLY("PC1min.ply",  withColors = TRUE)
PC1 <- meshDist(PC1min, PC1max)
#rgl.snapshot('C:/Users/utilisateur/Desktop/Codes/R_codes/Extant+Extinct/DataPhy_PC1_Med.png')
#PC2
PC2max<-warpRefMesh(myWarpeMean, mesh.coord=R.gpa$consensus,pca_mean$shapes$shapes.comp2$max )
writePLY("PC2max.ply",  withColors = TRUE)
PC2min<-warpRefMesh(myWarpeMean, mesh.coord=R.gpa$consensus,pca_mean$shapes$shapes.comp2$min )
writePLY("PC2min.ply",  withColors = TRUE)
PC2 <- meshDist(PC2min, PC2max)
#rgl.snapshot('C:/Users/utilisateur/Desktop/Codes/R_codes/Extant+Extinct/DataPhy_PC2_Med.png')

#Export centroid size
#a<-matrix(R.gpa$Csize, nrow=108)
#row.names(a) <- as.matrix(rm_names)
#write.table(a , 'C:/Users/utilisateur/Desktop/Codes/R_codes/Extant+Extinct/DataPhy_centroid_mean.csv', row.names=TRUE, col.names=FALSE)

#Export Procrustes coords
#b<-matrix(R.gpa_mean$coords, nrow = 108)
#row.names(b)<- as.matrix(rm_names)
#write.csv(orpdata_exp, file = "C:/Users/utilisateur/Desktop/Codes/R_codes/Extant+Extinct/DataPhy_Procrustes_mean.csv")

#save the PC Data
#write.csv(orpdata_exp, file = "C:/Users/utilisateur/Desktop/Codes/R_codes/Extant+Extinct/DataPhy_PCscores_mean.csv")


###PGLS_Csize and Phylotest
##Import log centroid size mean from MorphoJ 
LogCsize <- read.table(file = "DataPhy_centroid_mean.csv", header = F, sep=";", skip = 0, fill = TRUE) #groups 
LogCsize <- unlist(LogCsize, use.names=FALSE)
tree <- read.tree("treePhy.TRE") #import tree
tree <- multi2di(tree)
tree$tip.label <- gsub("'","",tree$tip.label)
tree

gdf <- geomorph.data.frame(gpa_2d_mean, phy = tree)
match(tree$tip.label,rownames(gpa_2d_mean))

##Phylo_signal_Pagel's_lambda

phylosig(tree,gpa_2d_mean, method="K",test=TRUE)

##PGLS_Csize

rum.pgls <- procD.pgls(gpa_2d_mean ~ LogCsize, phy = tree, data = R.gpa_mean, 
                       iter = 999)
anova(rum.pgls)

#plot
Pgls.plot <- plot(rum.pgls, type = "regression", 
                 predictor = LogCsize, reg.type = "RegScore", 
                 pch = 21) 

###MANCOVA

mancovaphy_mean <- procD.lm(gpa_2d_mean~LogCsize*clade_mean, data = R.gpa_mean, effect.type = "F")
summary(mancovaphy_mean)

###REGRESSIONS_Csize_ALL_CLADES

##Unpooled

RegUnpooled<-procD.lm(R.gpa_mean$coords ~ LogCsize,)

gp<-as.factor(unlist(clade_mean))
names(gp) <-row.names(clade_mean)
col.gp <- col.gp1 <- c("#D55E00", '#009E73','#F0E442','#CC79A7','black')
names(col.gp) <- levels(gp)
col.gp <- col.gp[match(gp, names(col.gp))]
shp.gp <- c(24,22,21,23,20)
names(shp.gp) <- levels(gp)
shp.gp <- shp.gp[match(gp, names(shp.gp))]


#pdf('C:/Users/utilisateur/Desktop/Codes/R_codes/Extant+Extinct/RegUnpooled_DataPhy.pdf')
Reg.plot <- plot(RegUnpooled, type = "regression", 
                  predictor = LogCsize, reg.type = "RegScore",col="black",bg=col.gp, cex = 1.8,pch = shp.gp)   
dev.off()

Unpooled<-data.frame(LogCsize,Reg.plot$RegScore,clade_mean)

#ggplot(Unpooled, aes(x=LogCsize, y=Reg.plot$RegScore, color=clade_mean))+
  #geom_point()+ 
  #geom_smooth(formula = y ~ x, method = lm, se=FALSE, fullrange=F)+
  #scale_shape_manual(values=c(30))+ 
  #scale_color_manual(values=c("orangered", 'limegreen','goldenrod','dodgerblue','black'))+
  #scale_size_manual(values=c(4,4,4,4,4))+
  #theme_classic()
Reg_Unpooled <- lm(Reg.plot$RegScore ~ LogCsize, data = Unpooled)
summary(Reg_Unpooled)

#save the RegScore
#write.csv(Reg.plot$RegScore, file = "C:/Users/utilisateur/Desktop/Codes/R_codes/Extant+Extinct/DataPhy_RegScores_mean.csv")


##Pooled by clades

#Datapooled
RegPooledDataPhy <- read.csv("RegDataPhy.csv", sep=";")
MLogCsize<-scale(LogCsize)#Scaling


Pooled<-data.frame(MLogCsize,RegPooledDataPhy$RegScorePooled,RegPooledDataPhy$Clade)#Data.frame

Reg_Pooled <- lm(RegPooledDataPhy$RegScorePooled ~ MLogCsize, data = Pooled)
summary(Reg_Pooled)

pdf('C:/Users/utilisateur/Desktop/Codes/R_codes/Extant+Extinct/RegPooled_DataPhy.pdf')
plot(RegPooledDataPhy$RegScorePooled ~ MLogCsize, col="black", bg=col.gp,pch=shp.gp, cex=1.8)
dev.off()

#ShapeVisualisation


#RegressionCsizeUnPooled/Clade
Reg1max<-warpRefMesh(myWarpeMean, mesh.coord=R.gpa$coords[,,21],R.gpa$coords[,,97] )
#writePLY("Reg1max.ply",  withColors = TRUE)
Reg1min<-warpRefMesh(myWarpeMean, mesh.coord=R.gpa$coords[,,21],R.gpa$coords[,,55] )
#writePLY("Reg1min.ply",  withColors = TRUE)
Reg1 <- meshDist(Reg1min, Reg1max)
#rgl.snapshot('C:/Users/utilisateur/Desktop/Codes/R_codes/Extant+Extinct/DataPhy_Reg1_Med.png')

#RegressionCsizePooled/Clade
Reg2max<-warpRefMesh(myWarpeMean, mesh.coord=R.gpa$coords[,,21],R.gpa$coord[,,15] )
#writePLY("Reg2max.ply",  withColors = TRUE)
Reg2min<-warpRefMesh(myWarpeMean, mesh.coord=R.gpa$coords[,,21],R.gpa$coord[,,108] )
#writePLY("Reg2min.ply",  withColors = TRUE)
Reg2 <- meshDist(Reg2min, Reg2max)
#rgl.snapshot('C:/Users/utilisateur/Desktop/Codes/R_codes/Extant+Extinct/DataPhy_Reg2_Med.png')


#############Creation of Data_with_correction_of_Allometry######################


#Import coord (Regression residuals pooled by clade) from MorphoJ
coordDataRes <- read.csv("CoordDataPhyRes.csv", sep=";")
coordDataRes <- coordDataRes[,-1] 
coordDataRes <- arrayspecs(coordDataRes, 426, 3)

#names
dimnames(coordDataRes)[3] <- indivlist	#name of the species are applied to the dataset
dataRes<-list("land"=coordDataRes,"curves"=curves,"species"=indivlist,"clades"=clades) 

str(dataRes) #check that everything is in order

#check for NA data
any(is.na(dataRes$land))

#Residuals procrustes 
R.gpaRes <- gpagen(coordDataRes, curves=curves, ProcD = T) #GPA
gpa_2d_Res <- two.d.array(R.gpaRes$coords) #GPA coords


###CVA on Residuals Clade 

cvaphy<-CVA(gpa_2d_Res,group=clades,cv=T)
row.names(cvaphy$CVscores)<-indivlist[,1]
sink("C:/Users/utilisateur/Desktop/Codes/R_codes/Extant+Extinct/CVA_DataPhy_crossvalidation.csv") 
print(cvaphy)
sink()


#Plot CV12
gp<-as.factor(unlist(clades))
names(gp) <-row.names(clades)
col.gp <- col.gp1 <- c("#D55E00", '#009E73','#F0E442','#CC79A7','black')
names(col.gp) <- levels(gp)
col.gp <- col.gp[match(gp, names(col.gp))]

shp.gp <- c(24,22,21,23,19)
names(shp.gp) <- levels(gp)
shp.gp <- shp.gp[match(gp, names(shp.gp))]


pdf('C:/Users/utilisateur/Desktop/Codes/R_codes/Extant+Extinct/CVA_DataPhy12_mean.pdf')
plot(cvaphy$CVscores[,1], cvaphy$CVscores[,2], col="black",bg=col.gp, pch=21,cex=1.7,
     xlab=paste("CV1", paste(round(cvaphy$Var[1,2],1),"%")),
     ylab=paste("CV2", paste(round(cvaphy$Var[2,2],1),"%")))
#text(cvaphy$CVscores, pos=4, col=col.gp, cex=.7)
dev.off()

#Plot  CV34
pdf('C:/Users/utilisateur/Desktop/Codes/R_codes/Extant+Extinct/CVA_DataPhy34_mean.pdf')
plot(cvaphy$CVscores[,3], cvaphy$CVscores[,4], col="black",bg=col.gp, pch=21,cex=1.7,
     xlab=paste("CV3", paste(round(cvaphy$Var[3,2],1),"%")),
     ylab=paste("CV4", paste(round(cvaphy$Var[4,2],1),"%")))
#text(cvaphy$CVscores[,3], cvaphy$CVscores[,4], pos=4, col=col.gp, cex=.7)
dev.off()

##ShapeChanges

myWarpeMean2<-warpRefMesh(mymesh, mesh.coord=R.gpaRes$consensus,mshape(R.gpaRes$coords))

#CV1
meshCV1min<-warpRefMesh(myWarpeMean2, mesh.coord=R.gpaRes$coords[,,196],R.gpaRes$coords[,,73])
#writePLY("meshCV1min.ply",  withColors = TRUE)
meshCV1max<-warpRefMesh(myWarpeMean2, mesh.coord=R.gpaRes$coords[,,196],R.gpaRes$coords[,,62])
#writePLY("meshCV1max.ply",  withColors = TRUE)
meshdistCV1 <- meshDist(meshCV1min, meshCV1max)
#rgl.snapshot('C:/Users/utilisateur/Desktop/Codes/R_codes/DataPhy/DataPhy_CV1_Lat.png')

#CV2
meshCV2min<-warpRefMesh(myWarpeMean2, mesh.coord=R.gpaRes$coords[,,127],R.gpaRes$coords[,,44])
#writePLY("meshCV2min.ply",  withColors = TRUE)
meshCV2max<-warpRefMesh(myWarpeMean2, mesh.coord=R.gpaRes$coords[,,127],R.gpaRes$coords[,,102])
#writePLY("meshCV2max.ply",  withColors = TRUE)
meshdistCV2 <- meshDist(meshCV2min, meshCV2max)
#rgl.snapshot('C:/Users/utilisateur/Desktop/Codes/R_codes/DataPhy/DataPhy_CV2_Med.png')

#CV3
meshCV3min<-warpRefMesh(myWarpeMean2, mesh.coord=R.gpaRes$coords[,,196],R.gpaRes$coords[,,83])
#writePLY("meshCV3min.ply",  withColors = TRUE)
meshCV3max<-warpRefMesh(myWarpeMean2, mesh.coord=R.gpaRes$coords[,,196],R.gpaRes$coords[,,132])
#writePLY("meshCV3max.ply",  withColors = TRUE)
meshdistCV3 <- meshDist(meshCV3min, meshCV3max)
#rgl.snapshot('C:/Users/utilisateur/Desktop/Codes/R_codes/DataPhy/DataPhy_CV3_Med.png')

#CV4
meshCV4min<-warpRefMesh(myWarpeMean2,mesh.coord=R.gpaRes$coords[,,196],R.gpaRes$coords[,,69])
#writePLY("meshCV4min.ply",  withColors = TRUE)
meshCV4max<-warpRefMesh(myWarpeMean2,mesh.coord=R.gpaRes$coords[,,196],R.gpaRes$coords[,,17])
#writePLY("meshCV4max.ply",  withColors = TRUE)
meshdistCV4 <- meshDist(meshCV4min, meshCV4max)
#rgl.snapshot('C:/Users/utilisateur/Desktop/Codes/R_codes/DataPhy/DataPhy_CV4_Med.png')



#######Log CS values ploted on PHYLOGENY#################################################################

#Import data
tree2 <- read.tree("treeAll.TRE") #import tree
tree2 <- multi2di(tree2)
tree2$tip.label <- gsub("'","",tree2$tip.label)
tree2
plot(tree2,type = "fan")
pdf('C:/Users/utilisateur/Desktop/Codes/R_codes/Extant+Extinct/TreeAll.pdf')


cs<-read.table("CS.csv", sep=";", row.names = 1, header=TRUE)
match(row.names(cs),tree2$tip.label)

ln.CS<-log(setNames(cs$CS,
                    rownames(cs)))
obj<-contMap(tree2,ln.CS,plot=TRUE, fsize=1)
obj2<-plot(setMap(obj,c("white","#FFFFB2","#FECC5C","#FD8D3C",
                        "#E31A1C")), fsize=0.6)
pdf('C:/Users/utilisateur/Desktop/Codes/R_codes/Extant+Extinct/PhyloAllCS.pdf')
plot(setMap(obj,invert=TRUE,c("white","#FFFFB2","#FECC5C","#FD8D3C",
                              "#E31A1C")),type="fan", fsize=c(0.6), outline=F, lwd=3, offset=5)
dev.off()
