library(rgl) 
library(geomorph)
library(Morpho)
library(stats)
library(RColorBrewer)
library(vegan)
library(lattice)
library(RRphylo)
library(phytools)
library(car)
library(ggplot2)
library(ape)


###################DATA#########################################################

setwd("C:/Users/utilisateur/Desktop/Codes/R_codes/Extant")

###DATA####
coordData <- read.csv("CoordDataMod.csv", sep=";")
coordData <- coordData[,-1] 
coordData <- arrayspecs(coordData, 426, 3)

#open sliders file
curves<-as.matrix(read.table(file = "Courbes.csv", header = F, sep=";", skip = 0, fill = TRUE)) #semilandmarks curves

#names
indivlist <- read.table(file = "IndivDataMod.csv", header = F, sep=";", skip = 0, fill = TRUE) #names
dimnames(coordData)[3] <- indivlist	#name of the species are applied to the dataset

#habitat
habitat <- read.table(file = "HabitatDataMod.csv", header = F, sep=";", skip = 0, fill = TRUE) #groups 
habitat <- unlist(habitat, use.names=FALSE) #this step transform the dataset into "factors"

data<- list("land" = coordData, "curves"=curves, "species"=indivlist,"habitat"=habitat) #list with all previous files

str(data) #check that everything is in order


#check for NA data
any(is.na(data$land))

#gpa
R.gpa <- gpagen(coordData, curves=curves, ProcD = T) #GPA
gpa_2d <- two.d.array(R.gpa$coords) #GPA coords
row.names(gpa_2d) <- indivlist[,1]
#pca
pca <- gm.prcomp(R.gpa$coord)
#plot(pca, pch = 21, cex = 1.7, col = "black", bg=col.gp)
#text(pca$x[,1], pca$x[,2], cex = 0.7, pos = 4, col = col.gp)
#dev.off()



#####DATAMEAN###################################################################


#species
spe_class <- read.csv("SpeciesMod.csv", sep=";", header=F)
rum2d_sp <- cbind.data.frame(spe_class[,2], gpa_2d)
split_sp <- split(rum2d_sp, rum2d_sp[,1])
row.names(rum2d_sp) <- indivlist[,1]

#mean
for (i in 1:58)
{
  split_sp[[i]] <- split_sp[[i]][,2:1279]
  df <- list(unique(spe_class[,2]))
  assign(paste("sp",i, sep=""), as.matrix(split_sp[[i]]))
  
  if (nrow(get(paste("sp",i, sep=""))) > 1) {
    assign(paste("df",i, sep=""), arrayspecs(get(paste0("sp", i)), 426, 3))
    assign(paste("df",i, sep=""), mshape(get(paste0("df", i))))
  }		
  
  else	{	
    assign(paste("df",i, sep=""), matrix(get(paste0("sp", i)), ncol=1278))
    assign(paste("df",i, sep=""), arrayspecs(get(paste0("df", i)), 426, 3))
  }		
  
}

#New dataset with one specimen per species
data_58 <- bindArr(df1,df2,df3,df4,df5,df6,df7,df8,df9,df10,df11,df12,df13,df14,
                    df15,df16,df17,df18,df19,df20,df21,df22,df23,df24,df25,df26,
                    df27,df28,df29,df30,df31,df32,df33,df34,df35,df36,df37,df38,
                    df39,df40,df41,df42,df43,df44,df45,df46,df47,df48,df49,df50,
                    df51,df52,df53,df54,df55,df56,df57,df58, along =3)

#data_mean creation
rm_names <- as.data.frame(ls(split_sp))
dimnames(data_58)[3] <- rm_names
habitat_mean <- read.table(file = "HabitatDataMod_mean.csv", header = F, sep=";", skip = 0, fill = TRUE) #groups 
habitat_mean <- unlist(habitat_mean, use.names=FALSE) #this step transform the dataset into "factors"

clade_mean <- read.table(file = "CladeDataMod_mean.csv", header = F, sep=";", skip = 0, fill = TRUE) #groups 
clade_mean <- unlist(clade_mean, use.names=FALSE) 

mass_mean <- read.table(file = "MasseDataMod.csv", header = F, sep=";", skip = 0, fill = TRUE) #groups 
mass_mean <- unlist(mass_mean, use.names=FALSE) 

size_mean <- read.table(file = "DataMod_log_centroid_mean.csv", header = F, sep=";", skip = 0, fill = TRUE) #groups 
size_mean <- unlist(size_mean, use.names=FALSE) 

data_mean <- list("land" = data_58, "curves"=curves,"clades"=clade_mean, "species"=rm_names, "habitat"=habitat_mean,"mass"=mass_mean, "size"=size_mean)
str(data_mean)

#data-mean procrustes et pca
R.gpa_mean <- gpagen(data_58, curves=curves, ProcD = T) #GPA

pca_mean <- gm.prcomp(R.gpa_mean$coord)#PCA
plotOutliers(R.gpa_mean$coords) #Check for problems
orpdata_exp <- pca_mean$x

gpa_2d_mean <- two.d.array(R.gpa_mean$coords) #GPA coords
row.names(gpa_2d_mean) <- rm_names[,1]
#save the PROCRUSTES Data MEAN
write.csv(gpa_2d_mean, file = "C:/Users/utilisateur/Desktop/Codes/R_codes/Extant/Extantmean_Procrustes.csv")

###PCAVisualisation

#Plot
gp<-as.factor(unlist(habitat_mean))
names(gp) <-row.names(habitat_mean)
col.gp <- col.gp1 <- c('#009E73','#56B4E9','#999999','#E69F00')
names(col.gp) <- levels(gp)
col.gp <- col.gp[match(gp, names(col.gp))]

plot(pca_mean, pch = 21, cex = 1.7, col = "black", bg=col.gp)
text(pca_mean$x[,1], pca_mean$x[,2], cex = 0.7, pos = 4, col = col.gp)
dev.off()

##Shape
mymesh<-read.ply(file = "Palaeoryx_cordieri_NMB_Mp4631931.ply")

myWarpeMean<-warpRefMesh(mymesh, mesh.coord=R.gpa_mean$consensus,mshape(R.gpa_mean$coords))

#PC1
#PC1max<-warpRefMesh(myWarpeMean, mesh.coord=R.gpa_mean$consensus,pca_mean$shapes$shapes.comp1$max )
#writePLY("PC1max.ply",  withColors = TRUE)
#PC1min<-warpRefMesh(myWarpeMean, mesh.coord=R.gpa_mean$consensus,pca_mean$shapes$shapes.comp1$min )
#writePLY("PC1min.ply",  withColors = TRUE)
#PC1 <- meshDist(PC1max, PC1min)
#rgl.snapshot('C:/Users/utilisateur/Desktop/Codes/R_codes/DataMod/DataMod_PC1_.png')
#PC2
#PC2max<-warpRefMesh(myWarpeMean, mesh.coord=R.gpa_mean$consensus,pca$shapes$shapes.comp2$max )
#writePLY("PC2max.ply",  withColors = TRUE)
#PC2min<-warpRefMesh(myWarpeMean, mesh.coord=R.gpa_mean$consensus,pca$shapes$shapes.comp2$min )
#writePLY("PC2min.ply",  withColors = TRUE)
#PC2 <- meshDist(PC2min, PC2max)
#rgl.snapshot('C:/Users/utilisateur/Desktop/Codes/R_codes/DataMod/DataMod_PC2_.png')


#save the PC Data MEAN
#write.csv(orpdata_exp, file = "C:/Users/utilisateur/Desktop/Codes/R_codes/Extant/Extantmean_PCscores.csv")

###Export centroid size#####
a<-matrix(R.gpa$Csize, nrow=86)
row.names(a) <- as.matrix(indivlist)
write.table(a , 'C:/Users/utilisateur/Desktop/Codes/R_codes/Extant/DataMod_centroid.csv', row.names=TRUE, col.names=FALSE)

###VARPART

mod <- varpart(gpa_2d_mean , ~clade_mean, ~habitat_mean, ~size_mean)
mod
summary(mod)
plot(mod,bg=c("tomato","limegreen","dodgerblue"),Xnames=c("Clade","Habitat","Size"))

#Show values for all partitions by putting 'cutoff' low enough:
pdf('C:/Users/utilisateur/Desktop/Codes/R_codes/Extant/DataMOD_Varpart.pdf')
plot(mod, Xnames=c("Clade","Habitat","Size"),cutoff = -Inf, cex = 1, bg=c("tomato","limegreen","dodgerblue"))
dev.off()


###MANCOVA Shape~Mass*Habitat

mancovaeco_mean <- procD.lm(gpa_2d_mean~size_mean*habitat_mean, data = R.gpa_mean, effect.type = "F")
summary(mancovaeco_mean)


###PGLS Shape~Size*Habitat

tree <- read.tree("treeMod.TRE") #import tree
tree <- multi2di(tree)
tree$tip.label <- gsub("'","",tree$tip.label)
tree

gdf <- geomorph.data.frame(gpa_2d_mean, phy = tree)
match(tree$tip.label,rownames(gpa_2d_mean))

rum.pgls <- procD.pgls(gpa_2d_mean ~ size_mean*habitat_mean, phy = tree, data = R.gpa_mean, 
                       iter = 999)
anova(rum.pgls)

###ANOVA Csize~LogMass

masssize <- lm(LogCsize~mass_mean)
summary(masssize)

gp<-as.factor(unlist(habitat))
names(gp) <-row.names(habitat)
col.gp <- col.gp1 <- c('#009E73','#56B4E9','#999999','#E69F00')
names(col.gp) <- levels(gp)
col.gp <- col.gp[match(gp, names(col.gp))]
shp.gp <- c(23,22,24,21)
names(shp.gp) <- levels(gp)
shp.gp <- shp.gp[match(gp, names(shp.gp))]
plot(mass_mean~LogCsize, col="black",bg=col.gp, pch=shp.gp,cex=1.7)


###Regression

##import_Species_mean_Csize 

RegUnpooled<-procD.lm(R.gpa_mean$coords ~ LogCsize)


LogCsize <- read.table(file = "DataMod_centroid_mean.csv", header = F, sep=";", skip = 0, fill = TRUE) #groups 
LogCsize <- unlist(LogCsize, use.names=FALSE)
RegUnpooled<-procD.lm(R.gpa_mean$coords ~ LogCsize)

pdf('C:/Users/utilisateur/Desktop/Codes/R_codes/Extant/RegUnpooled_DataMod.pdf')
Reg.plot <- plot(RegUnpooled, type = "regression", 
                 predictor = LogCsize, reg.type = "RegScore",col="black",bg=col.gp, cex = 1.8,pch = shp.gp)   
dev.off()

Unpooled<-data.frame(LogCsize,Reg.plot$RegScore,habitat_mean)
Reg_Unpooled <- lm(Reg.plot$RegScore ~ LogCsize, data = Unpooled)
summary(Reg_Unpooled)

#ggplot(Unpooled, aes(x=LogCsize, y=Reg.plot$RegScore, color=habitat_mean))+
  #geom_point()+ 
  #geom_smooth(formula = y ~ x, method = lm, se=FALSE, fullrange=F)+
  #scale_shape_manual(values=c(30))+ 
  #scale_color_manual(values=c('turquoise','darkgreen',"darkgrey",'orange'))+
  #scale_size_manual(values=c(4,4,4,4))+
  #theme_classic()

Reg1max<-warpRefMesh(myWarpeMean, mesh.coord=R.gpa_mean$coords[,,21],R.gpa_mean$coords[,,26] )
#writePLY("Reg1max.ply",  withColors = TRUE)
Reg1min<-warpRefMesh(myWarpeMean, mesh.coord=R.gpa_mean$coords[,,21],R.gpa_mean$coords[,,57] )
#writePLY("Reg1min.ply",  withColors = TRUE)
Reg1 <- meshDist(Reg1min, Reg1max)
rgl.snapshot('C:/Users/utilisateur/Desktop/Codes/R_codes/Extant/DataMod_Reg1_Med.png')



#############Creation of Data_with_correction_of_Allometry######################


#Import coord (Regression residuals) from MorphoJ
coordDataModRes <- read.csv("CoordDataModRes.csv", sep=";")
coordDataModRes <- coordDataModRes[,-1] 
coordDataModRes <- arrayspecs(coordDataModRes, 426, 3)

#names
dimnames(coordDataModRes)[3] <- indivlist	#name of the species are applied to the dataset
dataRes<-list("land"=coordDataModRes,"curves"=curves,"species"=indivlist,"habitat"=habitat) 

str(dataRes) #check that everything is in order


#check for NA data
any(is.na(dataRes$land))

#Residuals procrustes 
R.gpaRes <- gpagen(coordDataModRes, curves=curves, ProcD = T) #GPA
gpa_2d_Res <- two.d.array(R.gpaRes$coords) #GPA coords

#species
rum2dRes_sp <- cbind.data.frame(spe_class[,2], gpa_2d_Res)
splitRes_sp <- split(rum2dRes_sp, rum2dRes_sp[,1])
row.names(rum2dRes_sp) <- indivlist[,1]

###mean
for (i in 1:58)
{
  splitRes_sp[[i]] <- splitRes_sp[[i]][,2:1279]
  df <- list(unique(spe_class[,2]))
  assign(paste("sp",i, sep=""), as.matrix(splitRes_sp[[i]]))
  
  if (nrow(get(paste("sp",i, sep=""))) > 1) {
    assign(paste("df",i, sep=""), arrayspecs(get(paste0("sp", i)), 426, 3))
    assign(paste("df",i, sep=""), mshape(get(paste0("df", i))))
  }		
  
  else	{	
    assign(paste("df",i, sep=""), matrix(get(paste0("sp", i)), ncol=1278))
    assign(paste("df",i, sep=""), arrayspecs(get(paste0("df", i)), 426, 3))
  }		
  
}

#New dataset with one specimen per species
data_58Res <- bindArr(df1,df2,df3,df4,df5,df6,df7,df8,df9,df10,df11,df12,df13,df14,
                      df15,df16,df17,df18,df19,df20,df21,df22,df23,df24,df25,df26,
                      df27,df28,df29,df30,df31,df32,df33,df34,df35,df36,df37,df38,
                      df39,df40,df41,df42,df43,df44,df45,df46,df47,df48,df49,df50,
                      df51,df52,df53,df54,df55,df56,df57,df58,along =3)

#data_mean creation
rmRes_names <- as.data.frame(ls(splitRes_sp))
dimnames(data_58Res)[3] <- rmRes_names
habitat_mean <- read.table(file = "HabitatDataMod_mean.csv", header = F, sep=";", skip = 0, fill = TRUE) #groups 
habitat_mean <- unlist(habitat_mean, use.names=FALSE) #this step transform the dataset into "factors"



dataRes_mean <- list("land" = data_58Res, "curves"=curves,"habitat"=clade_mean, "species"=rmRes_names)
str(dataRes_mean)

###data-mean procrustes et pca
R.gpaRes_mean <- gpagen(data_58Res, curves=curves, ProcD = T) #GPA

plotOutliers(R.gpaRes_mean$coords) #Check for problems

gpaRes_2d_mean <- two.d.array(R.gpaRes_mean$coords) #GPA coords
row.names(gpaRes_2d_mean) <- rmRes_names[,1]

#pca res mean

pcaRes_mean <- gm.prcomp(R.gpaRes_mean$coords)#PCA
orpdataRes_exp <- pcaRes_mean$x
write.csv(orpdataRes_exp, file = "C:/Users/utilisateur/Desktop/Codes/R_codes/Extant/ExtantmeanRes_PCscores.csv")


#CVA_Res_mean_5PCscores

PC5scores<-read.csv(file ="5PCscores.csv",sep=";", header=F)
PC5scores<-PC5scores[,-1]
row.names(PC5scores)<-rm_names[,1]

cva5PC_mean<-CVA(PC5scores,group=habitat_mean,cv=T)
row.names(cva5PC_mean$CVscores)<-rm_names[,1]

gp<-as.factor(unlist(habitat_mean))
names(gp) <-row.names(habitat_mean)
col.gp <- col.gp1 <- c('#56B4E9','#009E73','#999999','#E69F00')
names(col.gp) <- levels(gp)
col.gp <- col.gp[match(gp, names(col.gp))]
shp.gp <- c(22,23,24,21)
names(shp.gp) <- levels(gp)
shp.gp <- shp.gp[match(gp, names(shp.gp))]

pdf('C:/Users/utilisateur/Desktop/Codes/R_codes/Extant/CVApc5mean_DataMOD.pdf')
plot(cva5PC_mean$CVscores, col="black",bg=col.gp, pch=shp.gp,cex=1.7,
     xlab=paste("CV1", paste(round(cva5PC_mean$Var[1,2],1),"%")),
     ylab=paste("CV2", paste(round(cva5PC_mean$Var[2,2],1),"%")))
text(cva5PC_mean$CVscores, pos=4, col=col.gp, cex=.7)
dev.off()



#CVA_mean Residuals
cvahab_mean<-CVA(gpaRes_2d_mean,group=habitat_mean,cv=T)
row.names(cvahab_mean$CVscores)<-rm_names[,1]
sink("C:/Users/utilisateur/Desktop/Codes/R_codes/Extant/CVAmean_DataMod_crossvalidation.csv") 
print(cvahab_mean)
sink()

gp<-as.factor(unlist(habitat_mean))
names(gp) <-row.names(habitat_mean)
col.gp <- col.gp1 <- c('#56B4E9','#009E73','#999999','#E69F00')
names(col.gp) <- levels(gp)
col.gp <- col.gp[match(gp, names(col.gp))]
shp.gp <- c(22,23,24,21)
names(shp.gp) <- levels(gp)
shp.gp <- shp.gp[match(gp, names(shp.gp))]

pdf('C:/Users/utilisateur/Desktop/Codes/R_codes/Extant/CVAmean_DataMOD.pdf')
plot(cvahab_mean$CVscores, col="black",bg=col.gp, pch=shp.gp,cex=1.7,
     xlab=paste("CV1", paste(round(cvahab_mean$Var[1,2],1),"%")),
     ylab=paste("CV2", paste(round(cvahab_mean$Var[2,2],1),"%")))
text(cvahab_mean$CVscores, pos=4, col=col.gp, cex=.7)
dev.off()



##MorphingCVA

mymesh2<-read.ply(file = "Palaeoryx_cordieri_NMB_Mp4631931.ply")
myWarpeMean<-warpRefMesh(mymesh2, mesh.coord=R.gpaRes_mean$consensus,mshape(R.gpaRes_mean$coords))

#CV1
CV1Mmin<-warpRefMesh(myWarpeMean, mesh.coord=R.gpaRes_mean$coord[,,17],R.gpaRes_mean$coord[,,38] )
#writePLY("CV1min.ply",  withColors = TRUE)
CV1Mmax<-warpRefMesh(myWarpeMean, mesh.coord=R.gpaRes_mean$coord[,,17],R.gpaRes_mean$coord[,,7] )
#writePLY("CV1max.ply",  withColors = TRUE)
CV1Mean <- meshDist(CV1Mmin, CV1Mmax)
#rgl.snapshot('C:/Users/utilisateur/Desktop/Codes/R_codes/Extant/DataModmean_CV1_Med.png')

#CV2
CV2Mmin<-warpRefMesh(myWarpeMean, mesh.coord=R.gpaRes_mean$coord[,,17],R.gpaRes_mean$coord[,,44] )
#writePLY("CV2Mmin.ply",  withColors = TRUE)
CV2Mmax<-warpRefMesh(myWarpeMean, mesh.coord=R.gpaRes_mean$coord[,,17],R.gpaRes_mean$coord[,,1] )
#writePLY("CV2Mmax.ply",  withColors = TRUE)
CV2Mean <- meshDist(CV2Mmin, CV2Mmax)
rgl.snapshot('C:/Users/utilisateur/Desktop/Codes/R_codes/Extant/DataModmean_CV2_Med.png')


#CV1
deformGrid3d(R.gpaRes_mean$coord[,,7],R.gpaRes_mean$coord[,,38],ngrid = 0)

#CV2
deformGrid3d(R.gpaRes_mean$coord[,,44],R.gpaRes_mean$coord[,,1],ngrid = 0)





###BGPCA MEAN 
gpcaRes_mean <- groupPCA(gpaRes_2d_mean, groups=habitat_mean, rounds=10000, mc.cores=2, cv=TRUE)

sink("C:/Users/utilisateur/Desktop/Codes/R_codes/Extant/BgPCAmean_Extant_crossvalidation.csv") 
print(gpcaRes_mean)
sink()



pdf('C:/Users/utilisateur/Desktop/Codes/R_codes/Extant/bgPCA_Extant_12_mean.pdf')
plot(gpcaRes_mean$Scores[,1], gpcaRes_mean$Scores[,2], col="black",bg=col.gp, pch=shp.gp,cex=1.7,
     xlab=paste("PC1"),
     ylab=paste("PC2"))
#text(gpcaRes_mean$Scores[,1],gpcaRes_mean$Scores[,2], pos=4, col=col.gp, cex=.7)
dev.off()



