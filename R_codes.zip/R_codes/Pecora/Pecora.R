library(rgl) 
library(geomorph)
library(Morpho)
library(stats)
library(RColorBrewer)
library(vegan)
library(lattice)
library(RRphylo)
library(phytools)
library(ggplot2)
library(dplyr)
library(car)
library(cluster)

setwd("C:/Users/utilisateur/Desktop/Codes/R_codes/Pecora")
#############Creation of Data_mean_without_correction_of_Allometry##############

#Import coord from MorphoJ
coordData <- read.csv("CoordPecora.csv", sep=";")
coordData <- coordData[,-1] 
coordData <- arrayspecs(coordData, 426, 3)

#open sliders file
curves<-as.matrix(read.table(file = "Courbes.csv", header = F, sep=";", skip = 0, fill = TRUE)) #semilandmarks curves

#names
indivlist <- read.table(file = "IndivPecora.csv", header = F, sep=";", skip = 0, fill = TRUE) #names
dimnames(coordData)[3] <- indivlist	#name of the species are applied to the dataset

clades <- read.table(file = "CladePecora.csv", header = F, sep=";", skip = 0, fill = TRUE) #groups 
clades <- unlist(clades, use.names=FALSE)

data<- list("land" = coordData, "curves"=curves, "species"=indivlist,"clades"=clades) #list with all previous files

str(data) #check that everything is in order


#check for NA data
any(is.na(data$land))

#gpa
R.gpa <- gpagen(coordData, curves=curves, ProcD = T)
gpa_2d <- two.d.array(R.gpa$coords) #GPA coords
row.names(gpa_2d) <- indivlist[,1]

#species
spe_class <- read.csv("SpeciesPecora.csv", sep=";", header=F)
rum2d_sp <- cbind.data.frame(spe_class[,2], gpa_2d)
split_sp <- split(rum2d_sp, rum2d_sp[,1])
row.names(rum2d_sp) <- indivlist[,1]

###mean
for (i in 1:96)
{
  split_sp[[i]] <- split_sp[[i]][,2:1279]
  df <- list(unique(spe_class[,2]))
  assign(paste("sp",i, sep=""), as.matrix(split_sp[[i]]))
  
  if (nrow(get(paste("sp",i, sep=""))) > 1) {
    assign(paste("df",i, sep=""), arrayspecs(get(paste0("sp", i)), 426, 3))
    assign(paste("df",i, sep=""), mshape(get(paste0("df", i))))
  }		
  
  else	{	
    assign(paste("df",i, sep=""), matrix(get(paste0("sp", i)), ncol=1278))
    assign(paste("df",i, sep=""), arrayspecs(get(paste0("df", i)), 426, 3))
  }		
  
}

#New dataset with one specimen per species
data_96 <- bindArr(df1,df2,df3,df4,df5,df6,df7,df8,df9,df10,df11,df12,df13,df14,
                    df15,df16,df17,df18,df19,df20,df21,df22,df23,df24,df25,df26,
                    df27,df28,df29,df30,df31,df32,df33,df34,df35,df36,df37,df38,
                    df39,df40,df41,df42,df43,df44,df45,df46,df47,df48,df49,df50,
                    df51,df52,df53,df54,df55,df56,df57,df58,df59,df60,df61,df62,
                    df63,df64,df65,df66,df67,df68,df69,df70,df71,df72,df73,df74,
                    df75,df76,df77,df78,df79,df80,df81,df82,df83,df84,df85,df86,
                    df87,df88,df89,df90,df91,df92,df93,df94,df95,df96,along =3)

#data_mean creation
rm_names <- as.data.frame(ls(split_sp))
dimnames(data_96)[3] <- rm_names
clade_mean <- read.table(file = "CladePecora_mean.csv", header = F, sep=";", skip = 0, fill = TRUE) #groups 
clade_mean <- unlist(clade_mean, use.names=FALSE) #this step transform the dataset into "factors"



data_mean <- list("land" = data_96, "curves"=curves,"clades"=clade_mean, "species"=rm_names)
str(data_mean)

###data-mean procrustes et pca
R.gpa_mean <- gpagen(data_96, curves=curves, ProcD = T) #GPA

##Modularity

Modules <- define.modules(R.gpa_mean$consensus, 2)



#2 trochlea prox. ; trochlea dist.
#land.gps <- rep('a',426); 
#land.gps[27:6]<- 'b';land.gps[27:56]<- 'b'; land.gps[187:206]<- 'b'; land.gps[277:286]<- 'b'; land.gps[327:346]<- 'b'; land.gps[377:406]<- 'b'; land.gps[5:6]<- 'b'; land.gps[3]<- 'b';
#land.gps[2]<- 'b'; land.gps[57:76]<- 'b'; land.gps[407:416]<- 'b'

#3 trochlea prox. ; trochlea dist. ; PAF
#land.gps <- rep('a',426); 
#land.gps[27:6]<- 'b';land.gps[27:56]<- 'b'; land.gps[187:206]<- 'b'; land.gps[277:286]<- 'b'; land.gps[327:346]<- 'b'; land.gps[377:406]<- 'b'; land.gps[5:6]<- 'b'; land.gps[3]<- 'b';
#land.gps[2]<- 'c'; land.gps[57:76]<- 'c'; land.gps[207:216]<- 'c';land.gps[407:426]<- 'c'

#4 trochlea prox. ; trochlea dist. ; PAF ; LDAF
#land.gps <- rep('a',426); 
#land.gps[27:6]<- 'b';land.gps[27:36]<- 'b';land.gps[47:56]<- 'b'; land.gps[187:206]<- 'b'; land.gps[277:286]<- 'b'; land.gps[327:346]<- 'b'; land.gps[377:406]<- 'b'; land.gps[5:6]<- 'b'; land.gps[3]<- 'b';
#land.gps[2]<- 'c'; land.gps[57:76]<- 'c'; land.gps[207:216]<- 'c';land.gps[407:426]<- 'c';
#land.gps[37:46]<- 'd'; land.gps[137:156]<- 'd'

#5 trochlea prox. ; trochlea dist. ; PAF ; LDAF ; Medial extension
#land.gps <- rep('a',426); 
#land.gps[27:6]<- 'b';land.gps[27:36]<- 'b';land.gps[47:56]<- 'b'; land.gps[187:206]<- 'b'; land.gps[277:286]<- 'b'; land.gps[327:346]<- 'b'; land.gps[377:406]<- 'b'; land.gps[5:6]<- 'b'; land.gps[3]<- 'b';
#land.gps[2]<- 'c'; land.gps[57:76]<- 'c'; land.gps[207:216]<- 'c';land.gps[407:426]<- 'c';
#land.gps[37:46]<- 'd'; land.gps[137:156]<- 'd';
#land.gps[217:236]<- 'e'; land.gps[167:186]<- 'e'

##Split
#2
#land.gps <- rep('a',426);
#land.gps[1:213]<-'b'

#3
#land.gps <- rep('a',426);
#land.gps[1:142]<-'b';
#land.gps[143:285]<-'c'

#4
#land.gps <- rep('a',426); 
#land.gps[1:107]<- 'b';
#land.gps[108:215]<- 'c'; 
#land.gps[216:323]<- 'd'

#5
#land.gps <- rep('a',426); 
#land.gps[1:85]<- 'b';
#land.gps[86:171]<- 'c'; 
#land.gps[172:257]<- 'd'; 
#land.gps[258:343]<- 'e'

#6 
#land.gps <- rep('a',426); 
#land.gps[1:71]<- 'b';
#land.gps[72:143]<- 'c'; 
#land.gps[144:215]<- 'd'; 
#land.gps[216:287]<- 'e';
#land.gps[288:359]<- 'f'

#7
#land.gps <- rep('a',426); 
#land.gps[1:62]<- 'b';
#land.gps[63:124]<- 'c'; 
#land.gps[125:186]<- 'd'; 
#land.gps[187:248]<- 'e';
#land.gps[249:310]<- 'f';
#land.gps[311:372]<-'g'

#8
#land.gps <- rep('a',426); 
#land.gps[1:53]<- 'b';
#land.gps[54:107]<- 'c'; 
#land.gps[108:161]<- 'd'; 
#land.gps[162:215]<- 'e';
#land.gps[216:269]<- 'f';
#land.gps[270:323]<-'g';
#land.gps[324:377]<-'h'


#9
#land.gps <- rep('a',426); 
#land.gps[1:47]<- 'b';
#land.gps[48:96]<- 'c'; 
#land.gps[97:145]<- 'd'; 
#land.gps[146:194]<- 'e';
#land.gps[195:243]<- 'f';
#land.gps[244:292]<-'g';
#land.gps[293:341]<-'h';
#land.gps[342:390]<-'i'

#10
#land.gps <- rep('a',426); 
#land.gps[1:43]<- 'b';
#land.gps[44:87]<- 'c'; 
#land.gps[88:131]<- 'd'; 
#land.gps[132:175]<- 'e';
#land.gps[176:219]<- 'f';
#land.gps[220:263]<-'g';
#land.gps[264:307]<-'h';
#land.gps[308:351]<-'i';
#land.gps[352:395]<-'j'

#30 all curves
#land.gps <- rep('a',426); land.gps[7:26]<- 'b'; land.gps[27:46]<- 'c'; 
#land.gps[47:56]<- 'd'; land.gps[57:66]<- 'e'; land.gps[67:76]<- 'f'; 
#land.gps[417:426]<- 'f';land.gps[77:86]<- 'g'; land.gps[287:296]<- 'g'; 
#land.gps[87:96]<- 'h'; land.gps[97:116]<- 'i'; land.gps[117:126]<- 'j'; 
#land.gps[127:136]<- 'k'; land.gps[137:156]<- 'l'; land.gps[157:166]<- 'm';
#land.gps[297:306]<- 'n'; land.gps[167:186]<- 'n'; land.gps[187:206]<- 'o'; 
#land.gps[207:216]<- 'p';land.gps[217:236]<- 'q'; land.gps[237:246]<- 'r'; 
#land.gps[247:256]<- 's'; land.gps[367:376]<- 's';land.gps[257:266]<- 't';
#land.gps[357:366]<- 't'; land.gps[267:276]<- 'u'; land.gps[277:286]<- 'v';
#land.gps[337:346]<- 'w'; land.gps[307:326]<- 'x'; land.gps[327:336]<- 'y';
#land.gps[377:386]<- 'z'; land.gps[347:356]<- 'aa'; land.gps[387:396]<- 'ab'; 
#land.gps[397:406]<- 'ac'; land.gps[407:416]<- 'ad'

#MT <- modularity.test(R.gpa_mean$coords,iter=9999,land.gps, CI = F, opt.rot = T)
#summary(MT) # Test summary
#plot(MT) # Histogram of CR sampling distribution 



##PCA
pca_mean <- gm.prcomp(R.gpa_mean$coord)#PCA

plotOutliers(R.gpa_mean$coords) #Check for problems

orpdata_exp <- pca_mean$x
gpa_2d_mean <- two.d.array(R.gpa_mean$coords) #GPA coords
row.names(gpa_2d_mean) <- rm_names[,1]

###PCAVisualisation

#Plot

gp<-as.factor(unlist(clade_mean))
names(gp) <-row.names(clade_mean)
col.gp <- col.gp1 <- c("#D55E00", '#009E73','#F0E442','#CC79A7' )
names(col.gp) <- levels(gp)
col.gp <- col.gp[match(gp, names(col.gp))]

shp.gp <- c(24,22,21,23)
names(shp.gp) <- levels(gp)
shp.gp <- shp.gp[match(gp, names(shp.gp))]

pdf('C:/Users/utilisateur/Desktop/Codes/R_codes/Pecora/PCA_Pecora12_mean.pdf')
plot(pca_mean, pch = shp.gp, cex = 1.7, col = "black", bg=col.gp)
text(pca_mean$x[,1], pca_mean$x[,2], cex = 0.7, pos = 4, col = col.gp)
dev.off()

##Shape
mymesh<-read.ply(file = "Palaeoryx_cordieri_NMB_Mp4631931.ply")

#myWarpeMean<-warpRefMesh(mymesh, mesh.coord=R.gpa$consensus,mshape(R.gpa$coords))
#writePLY("myWarpeMean.ply",  withColors = TRUE)
#PC1
PC1max<-warpRefMesh(myWarpeMean, mesh.coord=R.gpa$consensus,pca_mean$shapes$shapes.comp1$max )
#writePLY("PC1max.ply",  withColors = TRUE)
PC1min<-warpRefMesh(myWarpeMean, mesh.coord=R.gpa$consensus,pca_mean$shapes$shapes.comp1$min )
#writePLY("PC1min.ply",  withColors = TRUE)
PC1 <- meshDist(PC1min, PC1max)
#rgl.snapshot('C:/Users/utilisateur/Desktop/Codes/R_codes/Pecora/Pecora_PC1_Med.png')
#PC2
PC2max<-warpRefMesh(myWarpeMean, mesh.coord=R.gpa$consensus,pca_mean$shapes$shapes.comp2$max )
writePLY("PC2max.ply",  withColors = TRUE)
PC2min<-warpRefMesh(myWarpeMean, mesh.coord=R.gpa$consensus,pca_mean$shapes$shapes.comp2$min )
writePLY("PC2min.ply",  withColors = TRUE)
PC2 <- meshDist(PC2min, PC2max)
#rgl.snapshot('C:/Users/utilisateur/Desktop/Codes/R_codes/Pecora/Pecora_PC2_Med.png')

#Export centroid size
#a<-matrix(R.gpa$Csize, nrow=108)
#row.names(a) <- as.matrix(rm_names)
#write.table(a , 'C:/Users/utilisateur/Desktop/Codes/R_codes/Pecora/Pecora_centroid_mean.csv', row.names=TRUE, col.names=FALSE)

#Export Procrustes coords
#b<-matrix(R.gpa_mean$coords, nrow = 108)
#row.names(b)<- as.matrix(rm_names)
#write.csv(orpdata_exp, file = "C:/Users/utilisateur/Desktop/Codes/R_codes/Pecora/Pecora_Procrustes_mean.csv")

#save the PC Data
#write.csv(orpdata_exp, file = "C:/Users/utilisateur/Desktop/Codes/R_codes/Pecora/Pecora_PCscores_mean.csv")


###REGRESSION_Csize_PECORA

#Data
RegPecora <- read.csv("Centroid_Pecora.csv", sep=";")


##Unpooled

RegUnpooled<-procD.lm(R.gpa_mean$coords ~ RegPecora$CS)
summary(RegUnpooled)


#plot
gp<-as.factor(unlist(clade_mean))
names(gp) <-row.names(clade_mean)
col.gp <- col.gp1 <- c("#D55E00", '#009E73','#F0E442','#CC79A7')
names(col.gp) <- levels(gp)
col.gp <- col.gp[match(gp, names(col.gp))]
shp.gp <- c(24,22,21,23)
names(shp.gp) <- levels(gp)
shp.gp <- shp.gp[match(gp, names(shp.gp))]

#pdf('C:/Users/utilisateur/Desktop/Codes/R_codes/Pecora/RegUnpooled_Pecora.pdf')
Reg1.plot <- plot(RegUnpooled, type = "regression", 
                  predictor = RegPecora$CS, reg.type = "RegScore",col="black",bg=col.gp, cex = 1.8,pch = shp.gp)   
#dev.off()



Unpooled<-data.frame(RegPecora$CS,Reg1.plot$RegScore,clade_mean)
Reg_Unpooled <- lm(Reg1.plot$RegScore ~ RegPecora$CS, data = Unpooled)
summary(Reg_Unpooled)

#save the Residuals
write.csv(RegUnpooled$residuals, file = "C:/Users/utilisateur/Desktop/Codes/R_codes/Pecora/Pecora_RegUnpooledResiduals_mean.csv")

#save the RegScore
write.csv(Reg1.plot$RegScore, file = "C:/Users/utilisateur/Desktop/Codes/R_codes/Pecora/Pecora_RegScores_mean.csv")


##Pooled by clades

RegPooled<-lm(RegPecora$Centered_RegScore ~ RegPecora$CenteredCS)
summary(RegPooled)

#pdf('C:/Users/utilisateur/Desktop/Codes/R_codes/Pecora/RegPooled_Pecora.pdf')
plot(RegPecora$Centered_RegScore~RegPecora$CenteredCS, col="black",bg=col.gp, pch=shp.gp,cex=1.7)
#dev.off()

##ShapeVisualisation

#RegressionCsizeUnPooled/Clade

#Reg1max<-warpRefMesh(myWarpeMean, mesh.coord=R.gpa$coords[,,21],R.gpa$coords[,,97] )
#writePLY("Reg1max.ply",  withColors = TRUE)
#Reg1min<-warpRefMesh(myWarpeMean, mesh.coord=R.gpa$coords[,,21],R.gpa$coords[,,55] )
#writePLY("Reg1min.ply",  withColors = TRUE)
#Reg1 <- meshDist(Reg1min, Reg1max)
#rgl.snapshot('C:/Users/utilisateur/Desktop/Codes/R_codes/Pecora/Pecora_Reg1_Med.png')

#RegressionCsizePooled/Clade

#Reg2max<-warpRefMesh(myWarpeMean, mesh.coord=R.gpa$coords[,,21],R.gpa$coord[,,15] )
#writePLY("Reg2max.ply",  withColors = TRUE)
#Reg2min<-warpRefMesh(myWarpeMean, mesh.coord=R.gpa$coords[,,21],R.gpa$coord[,,108] )
#writePLY("Reg2min.ply",  withColors = TRUE)
#Reg2 <- meshDist(Reg2min, Reg2max)
#rgl.snapshot('C:/Users/utilisateur/Desktop/Codes/R_codes/Pecora/Pecora_Reg2_Med.png')


#############Creation of Data_with_correction_of_Allometry######################


#Import coord (Regression residuals pooled by clade) from MorphoJ
coordPecoraRes <- read.csv("CoordPecoraRes.csv", sep=";")
coordPecoraRes <- coordPecoraRes[,-1] 
coordPecoraRes <- arrayspecs(coordPecoraRes, 426, 3)

#names
dimnames(coordPecoraRes)[3] <- indivlist	#name of the species are applied to the dataset
dataRes<-list("land"=coordPecoraRes,"curves"=curves,"species"=indivlist,"clades"=clades) 

str(dataRes) #check that everything is in order


#check for NA data
any(is.na(dataRes$land))

#Residuals procrustes 
R.gpaRes <- gpagen(coordPecoraRes, curves=curves, ProcD = T) #GPA
gpa_2d_Res <- two.d.array(R.gpaRes$coords) #GPA coords

#species
rum2dRes_sp <- cbind.data.frame(spe_class[,2], gpa_2d_Res)
splitRes_sp <- split(rum2dRes_sp, rum2dRes_sp[,1])
row.names(rum2dRes_sp) <- indivlist[,1]

###mean
for (i in 1:96)
{
  splitRes_sp[[i]] <- splitRes_sp[[i]][,2:1279]
  df <- list(unique(spe_class[,2]))
  assign(paste("sp",i, sep=""), as.matrix(splitRes_sp[[i]]))
  
  if (nrow(get(paste("sp",i, sep=""))) > 1) {
    assign(paste("df",i, sep=""), arrayspecs(get(paste0("sp", i)), 426, 3))
    assign(paste("df",i, sep=""), mshape(get(paste0("df", i))))
  }		
  
  else	{	
    assign(paste("df",i, sep=""), matrix(get(paste0("sp", i)), ncol=1278))
    assign(paste("df",i, sep=""), arrayspecs(get(paste0("df", i)), 426, 3))
  }		
  
}

#New dataset with one specimen per species
data_96Res <- bindArr(df1,df2,df3,df4,df5,df6,df7,df8,df9,df10,df11,df12,df13,df14,
                   df15,df16,df17,df18,df19,df20,df21,df22,df23,df24,df25,df26,
                   df27,df28,df29,df30,df31,df32,df33,df34,df35,df36,df37,df38,
                   df39,df40,df41,df42,df43,df44,df45,df46,df47,df48,df49,df50,
                   df51,df52,df53,df54,df55,df56,df57,df58,df59,df60,df61,df62,
                   df63,df64,df65,df66,df67,df68,df69,df70,df71,df72,df73,df74,
                   df75,df76,df77,df78,df79,df80,df81,df82,df83,df84,df85,df86,
                   df87,df88,df89,df90,df91,df92,df93,df94,df95,df96,along =3)

#data_mean creation
rmRes_names <- as.data.frame(ls(splitRes_sp))
dimnames(data_96Res)[3] <- rmRes_names
clade_mean <- read.table(file = "CladePecora_mean.csv", header = F, sep=";", skip = 0, fill = TRUE) #groups 
clade_mean <- unlist(clade_mean, use.names=FALSE) #this step transform the dataset into "factors"



dataRes_mean <- list("land" = data_96Res, "curves"=curves,"clades"=clade_mean, "species"=rmRes_names)
str(dataRes_mean)

###data-mean procrustes et pca
R.gpaRes_mean <- gpagen(data_96Res, curves=curves, ProcD = T) #GPA

plotOutliers(R.gpaRes_mean$coords) #Check for problems

gpaRes_2d_mean <- two.d.array(R.gpaRes_mean$coords) #GPA coords
row.names(gpaRes_2d_mean) <- rmRes_names[,1]


###CVA on Residuals Clade #MEAN

cvaphy_mean<-CVA(gpaRes_2d_mean,group=clade_mean,cv=T)
row.names(cvaphy_mean$CVscores)<-rmRes_names[,1]
sink("C:/Users/utilisateur/Desktop/Codes/R_codes/Pecora/CVAmean_Pecora_crossvalidation.csv") 
print(cvaphy_mean)
sink()

sink("C:/Users/utilisateur/Desktop/Codes/R_codes/Pecora/CVAmean_Pecora_Grandm.csv") 
print(cvaphy_mean$Grandm)
sink()

classiPhyMean<-classify(cvaphy, cv = T, newdata = gpaRes_2d_mean, prior = NULL)
sink("C:/Users/utilisateur/Desktop/Codes/R_codes/Pecora/CVAphyMean_class.csv") 
print(classiPhyMean$posterior,)
sink()

resclass<-classify(cvaphy_mean, cv = T, newdata = gpaRes_2d_mean)#posterior proba
sink("C:/Users/utilisateur/Desktop/Codes/R_codes/Pecora/CVAPecora_posterior.csv")
print(resclass$posterior,)
sink()



#Plot CV12
gp<-as.factor(unlist(clade_mean))
names(gp) <-row.names(clade_mean)
col.gp <- col.gp1 <- c("#D55E00", '#009E73','#F0E442','#CC79A7')
names(col.gp) <- levels(gp)
col.gp <- col.gp[match(gp, names(col.gp))]

shp.gp <- c(24,22,21,23)
names(shp.gp) <- levels(gp)
shp.gp <- shp.gp[match(gp, names(shp.gp))]


pdf('C:/Users/utilisateur/Desktop/Codes/R_codes/Pecora/CVAmean_Pecora12_mean.pdf')
plot(cvaphy_mean$CVscores[,1], cvaphy_mean$CVscores[,2], col="black",bg=col.gp, pch=shp.gp,cex=1.7,
     xlab=paste("CV1", paste(round(cvaphy_mean$Var[1,2],1),"%")),
     ylab=paste("CV2", paste(round(cvaphy_mean$Var[2,2],1),"%")))
text(cvaphy_mean$CVscores, pos=4, col=col.gp, cex=.7)
dev.off()

#Plot  CV13
pdf('C:/Users/utilisateur/Desktop/Codes/R_codes/Pecora/CVAmean_Pecora23_mean.pdf')
plot(cvaphy_mean$CVscores[,3], cvaphy_mean$CVscores[,1], col="black",bg=col.gp, pch=shp.gp,cex=1.7,
     xlab=paste("CV3", paste(round(cvaphy_mean$Var[3,2],1),"%")),
     ylab=paste("CV1", paste(round(cvaphy_mean$Var[1,2],1),"%")))
#text(cvaphy_mean$CVscores[,3], cvaphy_mean$CVscores[,1], pos=4, col=col.gp, cex=.7)
dev.off()


##ShapeChanges

#Mesh

myWarpeMean2<-warpRefMesh(mymesh, mesh.coord=R.gpaRes_mean$consensus,mshape(R.gpaRes_mean$coords[,,30]))

#CV1
meshCV1min<-warpRefMesh(myWarpeMean2, mesh.coord=R.gpaRes_mean$coords[,,30],R.gpaRes_mean$coords[,,37])
#writePLY("meshCV1meanmin.ply",  withColors = TRUE)
meshCV1max<-warpRefMesh(myWarpeMean2, mesh.coord=R.gpaRes_mean$coords[,,30],R.gpaRes_mean$coords[,,5])
#writePLY("meshCV1meanmax.ply",  withColors = TRUE)
meshdistCV1 <- meshDist(meshCV1min, meshCV1max)
#rgl.snapshot('C:/Users/utilisateur/Desktop/Codes/R_codes/Pecora/Pecora_CV1mean_Med.png')

#CV2
meshMeanCV2min<-warpRefMesh(myWarpeMean2, mesh.coord=R.gpaRes_mean$coords[,,30],R.gpaRes_mean$coords[,,24])
#writePLY("meshMeanCV2min.ply",  withColors = TRUE)
meshMeanCV2max<-warpRefMesh(myWarpeMean2, mesh.coord=R.gpaRes_mean$coords[,,30],R.gpaRes_mean$coords[,,45])
#writePLY("meshMeanCV2max.ply",  withColors = TRUE)
meshdistCV2 <- meshDist(meshMeanCV2min, meshMeanCV2max)
#rgl.snapshot('C:/Users/utilisateur/Desktop/Codes/R_codes/Pecora/Pecora_CV2mean_Med.png')

#CV3
meshMeanCV3min<-warpRefMesh(myWarpeMean2, mesh.coord=R.gpaRes_mean$coords[,,30],R.gpaRes$coords[,,28])
#writePLY("meshCV3min.ply",  withColors = TRUE)
meshMeanCV3max<-warpRefMesh(myWarpeMean2, mesh.coord=R.gpaRes_mean$coords[,,30],R.gpaRes$coords[,,75])
#writePLY("meshCV3max.ply",  withColors = TRUE)
meshdistCV3 <- meshDist(meshMeanCV3min, meshMeanCV3max)
rgl.snapshot('C:/Users/utilisateur/Desktop/Codes/R_codes/Pecora/Pecora_CV3mean_Med.png')


###BGPCA MEAN PECORA
gpcaRes_mean <- groupPCA(gpaRes_2d_mean, groups=clade_mean, rounds=10000, mc.cores=2, cv=TRUE)

sink("C:/Users/utilisateur/Desktop/Codes/R_codes/Pecora/BgPCAmean_Pecora_crossvalidation.csv") 
print(gpcaRes_mean)
sink()



pdf('C:/Users/utilisateur/Desktop/Codes/R_codes/Pecora/bgPCA_Pecora_12_mean.pdf')
plot(gpcaRes_mean$Scores[,1], gpcaRes_mean$Scores[,2], col="black",bg=col.gp, pch=shp.gp,cex=1.7,
     xlab=paste("PC1"),
     ylab=paste("PC2"))
#text(gpcaRes_mean$Scores[,1],gpcaRes_mean$Scores[,2], pos=4, col=col.gp, cex=.7)
dev.off()
